<?php
session_start();

    if(isset($_SESSION['id'])){
        $username=($_SESSION['username']);
        $userId=($_SESSION['id']);
    }
        else{
            header("Location: dashboard.php");
    }
?>

<?php require_once "../includes/functions.php"; ?>

<?php 
    if (isset($_POST['register'])) {

      $studentName = $_POST['name'];
      $dob = $_POST['dob'];
      $gender = $_POST['gender'];
      $email = $_POST['email'];
      $phone= $_POST['phone'];
      $add= $_POST['add'];
      $session = $_POST['session'];
      $program= $_POST['program'];
      $semester= $_POST['semester'];

      $db = new db();

      if($db->std_entry($conn,$studentName,$dob,$gender,$email,$phone,$add,$session,$program,$semester)){
      echo "<script>alert('New entry was created')</script>";
      }
      else{
        echo "<script>alert('unable to create new entry.')</script>";
      }
    }
?> 

<!DOCTYPE html> 
<html>
    <head>
        <title>Students Registration</title>
        
        <link rel="icon" href="../images/AUN.png">
        <link rel="stylesheet" href="../bootstrap.min.css">
        <script src="../html5shiv.js"></script>
    </head>  
    
    <body>
        
        <!--- Navbar --->
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="dashboard.php" style="color: black;">ATTENDANCE 1.0</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="dashboard.php" style="font-size: 17px; text-transform: uppercase;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?></a>
                        </li>
                        <li>
                            <a href="logout.php" style="font-size: 16px;">LOGOUT</a>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
        
        
        <div class="container">
            <p style="margin-top: 100px; font-size: 16px;"><b>STUDENTS ENTRY</b></p>
            <hr>
            <form action="#" method="post">
            <div class="row" style="margin-top: 35px;">
                <div class="col-lg-3">
                    <input class="form-control" type="text" name="name" required placeholder="Student Name"><br>
                    <select class="form-control" required="" id="sex" name="gender">
                        <option>----- Gender -----</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option> 
                    </select><br>
                    <input class="form-control" type="tel" name="phone" required placeholder="Phone Number"><br>
                    <input class="form-control" type="text" name="session" required placeholder="Session"><br>
                    <select class="form-control" name="semester" required="" id="semester">
                        <option>------ Semester -----</option>
                        <option>1st</option>
                        <option>2nd</option>
                        <option>3rd</option> 
                        <option>4th</option>
                        <option>5th</option>
                        <option>6th</option>
                        <option>7th</option>
                        <option>8th</option>
                    </select>
                </div>
                
                <div class="col-lg-3">
                    <input type="date" class="form-control" id="dob" name="dob"><br>
                    <input class="form-control" type="email" name="email" required placeholder="E-mail Address"><br>
                    <input class="form-control" type="text" name="add" required placeholder="Address"><br>
                    <select class="form-control" name="program" required="" id="program">
                        <option>----- Program -----</option>
                        <option>MSC</option>
                        <option>BSC</option>
                        <option>PHD</option>
                    </select>
                </div>
            </div>
            <input class="btn btn-primary" style="margin-top: 35px; margin-left: 240px;" type="submit" value="Register" name="register">
            </form>
        </div>
        
        
        <footer class="footer" style="position: absolute; bottom:0; left: 0; width: 100%; height: auto; background-color: white; border: 1px solid rgba(0,0,0,0.1); box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p align="center" style="color: black; font-size: 16px; margin-top: 11px;">2017 AUN Attendance System | Developed By <a href="#">MODU & AKIM</a></p>
                    </div>
                </div>
            </div>
        </footer>
        
        <script src="../bootstrap.min.css"></script>
        <script src="../jquery.js"></script>
    </body>
</html>