<?php 
    require_once "../includes/functions.php"; 
?>

<?php $db = new db(); ?>

<?php
session_start();

    if(isset($_SESSION['id'])){
        $username=($_SESSION['username']);
        $userId=($_SESSION['id']);
    }
        else{
            header("Location: dashboard.php");
    }
?>
            
  <?php 
    if (isset($_POST['update'])):?>
      <?php
      $studentName = $_POST['name'];
      $dob = $_POST['dob'];
      $gender = $_POST['gender'];
      $email = $_POST['email'];
      $phone= $_POST['phone'];
      $add= $_POST['add'];
      $session = $_POST['session'];
      $program= $_POST['program'];
      $semester= $_POST['semester'];
      $rollno= $_GET ['std_roll_no'];

      if($db->update_std($conn,$studentName,$dob,$gender,$email,$phone,$add,$rollno,$session, $program, $semester)){
      $status= "Student's Information Updated Successfully";
      }
     ?>
     <?php endif ?> 

     <?php 
        $std_id = array();
        if (isset($_GET['std_roll_no'])) {
          $std_id = $_GET['std_roll_no'];
        }
    ?>

<!DOCTYPE html>
<html>
    <head>
        <title>Update Student's Record</title>
        
        <link rel="icon" href="../images/AUN.png">
        <link rel="stylesheet" href="../bootstrap.min.css">
        <script src="../html5shiv.js"></script>
    </head>  
    
    <body>
        
        <!--- Navbar --->
        <?php if (isset($_SESSION['id'])) { ?>
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="dashboard.php" style="color: black;">ATTENDANCE 1.0</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="dashboard.php" style="font-size: 17px; text-transform: uppercase;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?></a>
                        </li>
                        <li>
                            <a href="logout.php" style="font-size: 16px;">LOGOUT</a>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
        <?php } ?>
        
        <div class="container">
            <p style="margin-top: 100px; font-size: 16px;"><b>Updating Student</b></p>
            <hr>
            <?php 
            $update = $db->get_single_std($conn,"student_table",$std_id);
        ?>
          <?php foreach ($update as $key) { ?>


                <div class="row">
                    
                </div>
                <?php if (isset($status)): ?>

      <div class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <?php echo $status; ?>
      </div>


    <?php endif ?> 
            
            
            <form method="post" role="form" action="student_update.php?std_roll_no=<?php echo $key['std_roll_no']; ?>">
       <div class="container">
           <div class="row">
           <div class="col-lg-4">

          <div class="form-group">
            <label for="name"> Student Name(*) </label>
            <input type="text" name="name" class="form-control"  value="<?php echo $key['student_name']; ?>" required id="name" placeholder="student Name" >
          </div>
          </div>
           
           <div class="col-lg-4">
          <div class="form-group">
            <label for="dob"> Date Of Birth </label>
            <input type="date" name="dob" class="form-control" value="<?php echo $key['dob']; ?>" id="dob" >
          </div>
          </div>
        </div>
        </div> <!-- col-container-->
       
        <div class="container">
           <div class="row">

        <div class="col-lg-4">
          <div class="form-group">
          <label for="gender">Gender(*)</label>
           <select class="form-control" name="gender"  required id="gender" >
           <?php echo $key['gender']; ?>
           <option> </option>
           <option value="male">Male</option>
           <option value="female">Female</option> 
           </select>
          </div>
        </div>
          <!-- </div> -->
          <!-- <div class="col-lg-6 push-right">  -->
        <div class="col-lg-4">
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo $key['email']; ?>" required id="email" placeholder=" Email" >
          </div>
       </div>
       </div>
       </div><!-- col-container-->

      <div class="container">
       <div class="row">
       <div class="col-lg-4">
        <div class="form-group">
            <label for="phone">Phone </label>
            <input type="text" name="phone" class="form-control" value="<?php echo $key['phone']; ?>" id="phone" placeholder="Phone Number" >
          </div>
       </div>
       <div class="col-lg-4">
          <div class="form-group">
            <label for="add">Address</label>
            <textarea name="add" class="form-control"  id="add" placeholder="Your address please" rows="3" ><?php echo $key['address']; ?></textarea>
          </div>
       </div>
       </div>
     </div><!-- col-container-->
      <div class="container">
       <div class="row">
       <div class="col-lg-4">
      <div class="form-group">
            <label for="session" >Session</label>
            <input type="text" class="form-control" id="session" placeholder="session" name="session"  value="<?php echo $key['Session']; ?>" >
        </div>
        </div>
          <div class="col-lg-4">
          <div class="form-group">
          <label for="program"  class="col-sm-2 control-label">Program</label>
           <select  class="form-control" name="program"  required id="program" name="program"  value="<?php echo $key['Program']; ?>" >
          <option></option>
           <option >MCS</option>
           <option >BSCS</option>
           <option >BSSC</option>
           <option >Mphil</option>
           <option >PHD</option>
           </select>
          </div>  
          </div>
        </div>
          </div>

          <div class="col-lg-4">
          <div class="form-group">
          <label for="semester"  class="col-sm-2 control-label">Semester</label>
           <select  class="form-control" name="semester"  required id="semester"  value="<?php echo $key['Semester']; ?>"  >
           <option></option>
           <option>1st</option>
           <option>2nd</option>
           <option>3rd</option> 
           <option>4th</option>
           <option>5th</option>
           <option>6th</option>
           <option>7th</option>
           <option>8th</option>
           </select>
          </div>  
          </div>
          <!---<div "form-actions"> <br><br>
          <div class="ui mini buttons col-sm-offset-3 col-sm-3">
          <button type="submit" class="ui mini positive button" name="update">Update</button>
          <div class="or"></div>
          <a href="student.php" type="submit" class="ui mini button" name="back">Back</a>
          </div>
          </div>---->
                
        <div class="ui mini buttons col-sm-offset-3 col-sm-3" style="margin-top: 50px;">
          <button type="submit" class="btn btn-primary" name="update">Update</button>
          <button class="btn btn-default" type="button"><a href="student.php">Back</a></button>
          </div>        
       </form>
   <?php } ?>
            
        </div>
        
        
        <footer class="footer" style="position: absolute; bottom:0; left: 0; width: 100%; height: auto; background-color: white; border: 1px solid rgba(0,0,0,0.1); box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p align="center" style="color: black; font-size: 16px; margin-top: 11px;">2017 AUN Attendance System | Developed By <a href="#">MODU & AKIM</a></p>
                    </div>
                </div>
            </div>
        </footer>
        
        <script src="../bootstrap.min.css"></script>
        <script src="../jquery.js"></script>
    </body>
</html>