<?php
session_start();

    if(isset($_SESSION['id'])){
        $username=($_SESSION['username']);
        $userId=($_SESSION['id']);
    }
        else{
            header("Location: dashboard.php");
    }
?>

<?php require_once "../includes/functions.php"; ?>

<?php 
    if (isset($_POST['saved'])) {
    
      $subName = $_POST['subject'];
      $teacher= $_POST['teacher'];
      $field = $_POST['field'];
      $semester= $_POST['semester'];

      $db = new db();

      if($db->subject_entry($conn,$subName,$teacher,$field,$semester)){
        echo "<script>alert('Succesfully Saved')</script>";
      }
      else{
        echo "<script>alert('unable to Save.')</script>";
      }
    }
?> 

<!DOCTYPE html>
<html>
    <head>
        <title>Enter Subject Details</title>
        
        <link rel="icon" href="../images/AUN.png">
        <link rel="stylesheet" href="../bootstrap.min.css">
        <script src="../html5shiv.js"></script>
    </head>  
      
    <body>
        
        <!--- Navbar --->
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="dashboard.php" style="color: black;">ATTENDANCE 1.0</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="dashboard.php" style="font-size: 17px; text-transform: uppercase;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?></a>
                        </li>
                        <li>
                            <a href="logout.php" style="font-size: 16px;">LOGOUT</a>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
        
        
        <div class="container">
            <p style="margin-top: 100px; font-size: 16px;"><b>SUBJECT'S ENTRY</b></p>
            <hr>
            <form action="#" method="post">
            <div class="row" style="margin-top: 35px;">
                <div class="col-lg-3">
                    <select class="form-control" required="" id="teacher" name="subject">
                        <option>Select subject</option>
                        <option>C++</option>
                        <option>Java</option>
                        <option>MP</option>
                        <option>OOP</option>
                        <option>Others</option>
                    </select><br>
                    <select class="form-control" required="" id="semester" name="semester">
                        <option>Select semester</option>
                        <option>1st</option>
                        <option>2nd</option>
                        <option>3rd</option> 
                        <option>4th</option>
                        <option>5th</option>
                        <option>6th</option> 
                        <option>7th</option>
                        <option>8th</option>
                    </select>
                </div>
                 
                <div class="col-lg-3">
                   <select class="form-control" required="" id="field" name="field">
                        <option>Select field</option>
                        <option>BSCS</option>
                        <option>BSSC</option>
                        <option>MCS</option> 
                        <option>Ms</option>
                        <option>P.HD</option>
                    </select><br>
                    <?php 
                        //db connection
                        $con = mysqli_connect("localhost","root","","attendance_db");

                        //query
                        $sql=mysqli_query($con,"SELECT first_name,last_name FROM teacher_table");
                        if(mysqli_num_rows($sql)){
                        $select= '<select class="form-control" name="teacher">';
                        while($rs=mysqli_fetch_array($sql)){
                              $select.='<option value="'.$rs['first_name'].$rs['last_name'].'">'.$rs['first_name'].$rs['last_name'].'</option>';
                          }
                        }
                        $select.='</select>';
                        echo $select;
                    ?>
                </div>
            </div>
            <input class="btn btn-primary" style="margin-top: 35px; margin-left: 240px;" type="submit" value="Register" name="saved">
            </form>
        </div>
        
        
        <footer class="footer" style="position: absolute; bottom:0; left: 0; width: 100%; height: auto; background-color: white; border: 1px solid rgba(0,0,0,0.1); box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p align="center" style="color: black; font-size: 16px; margin-top: 11px;">2017 AUN Attendance System | Developed By <a href="#">MODU & AKIM</a></p>
                    </div>
                </div>
            </div>
        </footer>
        
        <script src="../bootstrap.min.css"></script>
        <script src="../jquery.js"></script>
    </body>
</html>