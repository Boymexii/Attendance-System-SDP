<?php
session_start();

    if(isset($_SESSION['id'])){
        $username=($_SESSION['username']);
        $userId=($_SESSION['id']);
    }
        else{
            header("Location: dashboard.php");
    }
?>

<?php require_once "../includes/functions.php"; ?>

<?php $db = new db(); ?>

<?php 
    if(isset($_GET['teacher_id'])){
    $t_id = $_GET['teacher_id'];

    if($db->delete_teacher_record($conn,'teacher_table',$t_id)){
       echo "Record was Deleted";
    }
} 
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Teacher Records</title>
        
        <link rel="icon" href="../images/AUN.png">
        <link rel="stylesheet" href="../bootstrap.min.css">
        <script src="../html5shiv.js"></script>
    </head>  
    
    <body>
        
        <!--- Navbar --->
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="dashboard.php" style="color: black;">ATTENDANCE 1.0</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="dashboard.php" style="font-size: 17px; text-transform: uppercase;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?></a>
                        </li>
                        <li>
                            <a href="logout.php" style="font-size: 16px;">LOGOUT</a>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
        
        
        <div class="container">
            <p style="margin-top: 100px; font-size: 16px;"><b>TEACHER RECORDS</b></p>
            <hr>
            <button class="btn btn-primary" type="button"><a href="teacher_entry.php" style="color: white;">+ INSERT</a></button>
            <table class="table table-bordered table-responsive table-hover" style="margin-top: 35px; font-size: 17px;">
               <thead>
                    <tr>
                  
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>DOB</th>
                      <th>Gender</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Degree</th>
                      <th>Salary</th>
                      <th>Address</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                <tbody>
                  <?php        
                    $veiw = $db->get_all_teacher($conn,'teacher_table',10);
                    foreach ($veiw as $post) {
                    $teacher_id = $post['teacher_id'];

                  echo '<tr>';


                    echo '<td>'. $post['first_name'] . '</td>';
                    echo '<td>'. $post['last_name'] . '</td>';
                    echo '<td>'. $post['dob'] . '</td>';
                    echo '<td>'. $post['gender'] . '</td>';
                    echo '<td>'. $post['email'] . '</td>';
                    echo '<td>'. $post['phone'] . '</td>';
                    echo '<td>'. $post['degree'] . '</td>';
                    echo '<td>'. $post['salary'] . '</td>';
                    echo '<td>'. $post['address'] . '</td>';

                    echo '<td width=250>';
                    echo "<div class='ui mini buttons'>";
                    echo '<a class="ui mini positive button" href="teacher_update.php?teacher_id='.$post['teacher_id'].'"> <i class="glyphicon glyphicon-pencil"></i>Update</a>';
                    echo "<div class='or'></div>";    
                    echo '<a class="ui mini red button" href="teacher.php?teacher_id='.$post['teacher_id'].'"><i class="glyphicon glyphicon-remove"> </i>Delete</a>';
                    echo "</div>";
                    echo '</td>';    
                   echo '</tr>';  
                    }
                ?>
                </tbody>     
            </table>
        </div>
        
        
        <footer class="footer" style="position: absolute; bottom:0; left: 0; width: 100%; height: auto; background-color: white; border: 1px solid rgba(0,0,0,0.1); box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p align="center" style="color: black; font-size: 16px; margin-top: 11px;">2017 AUN Attendance System | Developed By <a href="#">MODU & AKIM</a></p>
                    </div>
                </div>
            </div>
        </footer>
        
        <script src="../bootstrap.min.css"></script>
        <script src="../jquery.js"></script>
    </body>
</html>