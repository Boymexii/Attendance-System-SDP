<?php 
    require_once "../includes/functions.php"; 
    $db = new db();
?>

<?php
session_start();

    if(isset($_SESSION['id'])){
        $username=($_SESSION['username']);
        $userId=($_SESSION['id']);
    }
        else{
            header("Location: dashboard.php");
    }
?>


<?php
    if (isset($_POST['update'])):?>
      <?php
      $firstName = $_POST['name'];
      $lastName = $_POST['lname'];
      $dob = $_POST['dob'];
      $gender = $_POST['gender'];
      $email = $_POST['email'];
      $phone= $_POST['phone'];
      $degree= $_POST['degree'];
      $salary= $_POST['salary'];
      $address= $_POST['address'];
      $id= $_GET['teacher_id'];
      if($db->update_teacher_record($conn,$firstName,$lastName,$dob,$gender,$email,$phone,$degree,$salary,$address,$id)){
             $status= "Teacher's Information Updated Successfully";
        }
       ?>
     <?php endif ?>   

      <?php 
        $t_id = array();
        if (isset($_GET['teacher_id'])) {
          $t_id = $_GET['teacher_id'];
        }
?>
            

<!DOCTYPE html>
<html>
    <head>
        <title>Updating-Teacher's Record</title>
        
        <link rel="icon" href="../images/AUN.png">
        <link rel="stylesheet" href="../bootstrap.min.css">
        <script src="../html5shiv.js"></script>
    </head>  
    
    <body>
        
        <!--- Navbar --->
        <?php if (isset($_SESSION['id'])) { ?>
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="dashboard.php" style="color: black;">ATTENDANCE 1.0</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="dashboard.php" style="font-size: 17px; text-transform: uppercase;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?></a>
                        </li>
                        <li>
                            <a href="logout.php" style="font-size: 16px;">LOGOUT</a>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
        <?php } ?>
        
        <div class="container">
            <p style="margin-top: 100px; font-size: 16px;"><b>Update Teacher</b></p>
            <hr>
            <?php 
            $update = $db->get_single_teacher($conn,"teacher_table",$t_id);
        ?>
        <?php foreach ($update as $key) { ?>
               <div class="row">
                    
                </div>
        <?php if (isset($status)): ?>

            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <?php echo $status; ?>
            </div>

          <?php endif ?> 
            
            
        <form method="post" role="form" action="teacher_update.php?teacher_id=<?php echo $key['teacher_id']; ?>">
    <div class="container">
    <div class="row">
    <div class="col-lg-3">
          <div class="form-group">
            <label for="name" > First Name (*)</label>
            <input type="text" class="form-control" required id="name" placeholder="First Name" name="name" value="<?php echo $key['first_name']; ?>">
          </div>
    </div>
    <div class="col-lg-3">
          <div class="form-group">
            <label for="lname" > Last Name</label>
            <input type="text" class="form-control" required id="lname" placeholder="Last Name"  name="lname" value="<?php echo $key['last_name']; ?>">
          </div>
    </div>
    </div>
    </div>
    <div class="container">
    <div class="row">
    <div class="col-lg-3">
          <div class="form-group">
            <label for="dob"> Date Of Birth </label>
            <input type="date" class="form-control" id="dob" name="dob" value="<?php echo $key['dob']; ?>">
          </div>
    </div>
    <div class="col-lg-3">
          <div class="form-group">
          <label for="gender" >Gender</label>
           <select  class="form-control" name="gender" required id="sex" name="gender" >
           <?php echo $key['gender']; ?>
           <option>-------select-------</option>
           <option>Male</option>
           <option>Female</option> 
           </select>
          </div>
     </div>
     </div>
     </div>

     <div class="container">
    <div class="row">
    <div class="col-lg-3">
          <div class="form-group">
            <label for="email">Email address </label>
            <input type="email" class="form-control" required id="email" placeholder=" Email" name="email" value="<?php echo $key['email']; ?>">
          </div>
          </div>
    <div class="col-lg-3">
          <div class="form-group">
            <label for="phone">Phone </label>
            <input type="text" class="form-control" id="phone" placeholder="Phone Number" name="phone" value="<?php echo $key['phone']; ?>">
          </div>
    </div>
    </div>
    </div>
    <div class="container">
    <div class="row">
    <div class="col-lg-3">
           <div class="form-group">
          <label for="degree" >Degree</label>
           <select  class="form-control" name="degree"  required id="degree" name="degree">
           <?php echo $key['degree']; ?>
           <option>-------select-------</option>
           <option >Bachelor</option>
           <option >Master</option>
           <option >M.Phil</option>
           <option >P.HD</option>
           </select>
          </div>
          </div>

    <div class="col-lg-3">
          <div class="form-group">
            <label for="salary"> Salary </label>
            <input type="text" class="form-control" required id="salary" placeholder=" Enter salary"  name="salary" value="<?php echo $key['salary']; ?>">
          </div>
    </div>
    </div>
    </div>
    <div class="container">
    <div class="row">
    <div class="col-lg-3">
          <div class="form-group">
            <label for="address">Address</label>
            <textarea class="form-control" id="address" placeholder="Your address please" rows="3" name="address"><?php echo $key['address']; ?></textarea>
          </div>
          </div>
    </div>
    </div>

          <div class="ui mini buttons col-sm-offset-3 col-sm-3" style="margin-top: 10px;">
          <button type="submit" class="btn btn-primary" name="update">Update</button>
          <button class="btn btn-default" type="button"><a href="teacher.php">Back</a></button>
          </div>
       
       </form>
        <?php } ?>
            
        </div>
        
        
        <footer class="footer" style="position: absolute; bottom:0; left: 0; width: 100%; height: auto; background-color: white; border: 1px solid rgba(0,0,0,0.1); box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p align="center" style="color: black; font-size: 16px; margin-top: 11px;">2017 AUN Attendance System | Developed By <a href="#">MODU & AKIM</a></p>
                    </div>
                </div>
            </div>
        </footer>
        
        <script src="../bootstrap.min.css"></script>
        <script src="../jquery.js"></script>
    </body>
</html>