<?php
error_reporting(E_ALL & ~ E_NOTICE);
session_start();
?>

<?php
        //// Check for Admin and then login
        if ($_POST['submit']){
        include 'connection.php';
        $username=($_POST['username']);
        $password=($_POST['password']);

        $sql="SELECT id, username, password FROM admin WHERE username='$username' AND activated='1' LIMIT 1";
        $query=mysqli_query($dbcon, $sql);
        if($query){
          $row= mysqli_fetch_row($query);
          $userId= $row[0];
          $dbusername=$row[1];
          $dbpassword=$row[2];
        }
           if($username== $dbusername && $password== $dbpassword){
          $_SESSION['username']=$username;
          $_SESSION['id']=$userId;
          header('Location: admin/dashboard.php');
        }else{
            echo "<script>alert('User name or password is incorrect!')</script>";
          }            
           
       }  
 
?>

<?php
     //// Check for teacher and then login
       if ($_POST['submit']){
        include 'connection.php';
        $username=($_POST['username']);
        $password=($_POST['password']);

        $sql="SELECT teacher_id, username, password FROM teacher_table WHERE username='$username'";
        $query=mysqli_query($dbcon, $sql);
        if($query){
          $row= mysqli_fetch_row($query);
          $teacher_id= $row[0];
          $dbusername=$row[1];
          $dbpassword=$row[2];
        }
           if($username== $dbusername && $password== $dbpassword){
          $_SESSION['username']=$username;
          $_SESSION['teacher_id']=$teacher_id;
          header('Location: instructor/dashboard.php');
        }else{
            echo "<script>alert('User name or password is incorrect!')</script>";
          }            
           
       }  
 
?>

<?php
      /* if ($_POST['submit']){
        include 'connection.php';
        $username=($_POST['username']);
        $password=($_POST['password']);

        $sql="SELECT id, username, password FROM student WHERE username='$username' AND activated='1' LIMIT 1";
        $query=mysqli_query($dbcon, $sql);
        if($query){
          $row= mysqli_fetch_row($query);
          $userId= $row[0];
          $dbusername=$row[1];
          $dbpassword=$row[2];
        }
           if($username== $dbusername && $password== $dbpassword){
          $_SESSION['username']=$username;
          $_SESSION['id']=$userId;
          header('Location: student/dashboard.php');
        }else{
            echo "<script>alert('User name or password is incorrect!')</script>";
          }            
           
       }  
 */
?>

        <title>AUN Attendance Management System</title>
        <link href="bootstrap.min.css" rel='stylesheet' type='text/css'>
        <link href="style.css"  rel='stylesheet' type='text/css'> 
        <link href="AUN.png" rel="icon">
        <div class="container">

               <div class="row" align="center" style="margin-top: 80px; margin-bottom: 60px;">
                    <img src="AUN.png" class="img-responsive" style="width: 100px; height: 100px;">
                </div>
        </div>
     <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"> Sign In</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" action="#">
                                <div class="form-group">
                                    <input class="form-control" placeholder="User name" required name="username" type="username" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" required name="password" type="password" value="">
                                </div>
                                <div class="checkbox">
                                    <label> <input name="remember" type="checkbox" value="Remember Me">Remember Me</label>
                                </div>
                                <button type="sumbit" name="submit" value="login" class="btn btn-lg btn-success btn-block">Login</button>  
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>