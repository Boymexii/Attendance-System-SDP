<?php require_once "../includes/functions.php"; ?>

<?php
session_start();

    if(isset($_SESSION['teacher_id'])){
        $username=($_SESSION['username']);
        $userId=($_SESSION['teacher_id']);
    }
        else{
            header("Location: dashboard.php");
    }
?> 


<!DOCTYPE html> 
<html>
    <head>
        <title>Student Report</title>
        
        <link rel="icon" href="../images/AUN.png">
        <link rel="stylesheet" href="../bootstrap.min.css">
        <script src="../html5shiv.js"></script>
    </head>  
    
    <body>
        
        <!--- Navbar --->
        <?php if (isset($_SESSION['teacher_id'])) { ?>
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="dashboard.php" style="color: black;">ATTENDANCE 1.0</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="dashboard.php" style="font-size: 17px; text-transform: uppercase;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?></a>
                        </li>
                        <li>
                            <a href="logout.php" style="font-size: 16px;">LOGOUT</a>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
        <?php } ?>
        
        <div class="container">
            <p style="margin-top: 100px; font-size: 16px;">
                <b>Individual Searching</b> 
                <button class="btn btn-primary" style="float: right;" type="button"><a href="AttendanceForm.php" style="color: white;">Do Attendance</a></button>
                <button class="btn btn-primary" style="float: right; margin-right: 10px;" type="button"><a href="AttendanceReport.php" style="color: white;">Overall Report</a></button>
                <button class="btn btn-primary" style="float: right; margin-right: 10px;" type="button"><a href="SearchAttendReport.php" style="color: white;">Monthly Report</a></button>
            </p>
            <hr>
            <?php
                error_reporting(E_ALL ^ E_DEPRECATED);
                include("../config.php");
            ?>
            <form method="post" action="Search_Rpt.php" style="margin-top: 35px;">
                <!-- <div class="row"> -->
                 <div class="col-lg-8">
                  <div class="form-group">

                   <label for="student" >Student Name </label>
                  <?php
                  $qs=mysqli_query($connect,"select * from student_table" );	
                  echo "<select name='name' class='form-control' >";			

                  while($stid=mysqli_fetch_row($qs))
                  {				
                   echo"<option value=$stid[1] >$stid[1] </option>";
                   }
                  echo "</select>";

                  ?>
                 </div>
                <div class="form-group">
                  <label for="session" > Session</label>
                  <?php
                  $qs1=mysqli_query($connect,"select * from student_table");	
                  echo "<select name='session' class='form-control'>";			
                  while($session=mysqli_fetch_row($qs1))
                  {		

                   echo"<option value=$session[7]>$session[7] </option>";
                   }
                  echo "</select>";

                  ?>
                  </div>

                    <div class="form-group">
                  <label for="date" >Date</label> <!----<label style="color:red" >(date should be like YY-MM-DD)</label>---->
                  <input type="date" name="date" class="form-control">
                  </div>
                  </div>
                  <div class="col-lg-8"><br>
                  <button type="submit" class="btn btn-success btn-lg btn-block" value="Search" name="search">Search</button>
                  </div>

            </form>
        </div>
        
        
        <footer class="footer" style="position: absolute; bottom:0; left: 0; width: 100%; height: auto; background-color: white; border: 1px solid rgba(0,0,0,0.1); box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p align="center" style="color: black; font-size: 16px; margin-top: 11px;">2017 AUN Attendance System | Developed By <a href="#">MODU & AKIM</a></p>
                    </div>
                </div>
            </div>
        </footer>
        
        <script src="../bootstrap.min.css"></script>
        <script src="../jquery.js"></script>
    </body>
</html>