<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include("../config.php");
$stid=$_POST['stid'];
$subj=$_POST['subjid'];
$atten=$_POST['present'];
$date = date('Y-m-d H:i:s');
$query=mysqli_query($connect,"Insert into tbl_attendance (studentRollNumber,subjectId,attendance,Date)VALUES('$stid','$subj','$atten','$date')");
if(!$query)
{
	echo mysqli_error();
	}

?>

<?php
session_start();

    if(isset($_SESSION['teacher_id'])){
        $username=($_SESSION['username']);
        $userId=($_SESSION['teacher_id']);
    }
        else{
            header("Location: dashboard.php");
    }
?> 

<!DOCTYPE html>
<html>
    <head>
        <title>Attendance Recorded</title>
        
        <link rel="icon" href="../images/AUN.png">
        <link rel="stylesheet" href="../bootstrap.min.css">
        <script src="../html5shiv.js"></script>
    </head>  
    
    <body>  
        <p align="center">
            <button class="btn btn-primary" type="button"><a href="AttendanceForm.php">Go Back</a></button>
        </p>
    </body>
    
</html>
        