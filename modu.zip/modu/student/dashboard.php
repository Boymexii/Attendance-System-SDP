<?php require_once "../includes/functions.php"; ?>

<?php
session_start();

    if(isset($_SESSION['id'])){
        $username=($_SESSION['username']);
        $userId=($_SESSION['id']);
    }
        else{
            header("Location: dashboard.php");
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <?php if (isset($_SESSION['id'])) { ?>
        <title><?php echo $_SESSION['username']; ?>'s Dashboard</title>
        <?php } ?>
        
        <link rel="icon" href="../images/AUN.png">
        <link rel="stylesheet" href="../bootstrap.min.css">
        <script src="../html5shiv.js"></script>
    </head>  
    
    <body>
        
        <!--- Navbar --->
        <?php if (isset($_SESSION['id'])) { ?>
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="dashboard.php" style="color: black;">ATTENDANCE 1.0</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="dashboard.php" style="font-size: 17px; text-transform: uppercase;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?></a>
                        </li>
                        <li>
                            <a href="#" style="font-size: 16px;">LOGOUT</a>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
        <?php } ?>
        
        <div class="container">
            <p style="margin-top: 100px; font-size: 16px;"><b>TO DO</b></p>
            <hr>
            <table class="table table-bordered table-responsive table-hover" style="width: 400px; margin-top: 35px; font-size: 17px;">
                <tr style="background-color: #428bca; color: white;">
                    <td>Courses</td>
                </tr>
                <tr>
                    <td><a href="#" style="color: inherit;"></a></td>
                </tr>
                <tr>
                    <td><a href="#" style="color: inherit;"></a></td>
                </tr>
                <tr>
                    <td><a href="#" style="color: inherit;"></a></td>
                </tr>
                <tr></tr>
            </table>
        </div>
        
        
        <footer class="footer" style="position: absolute; bottom:0; left: 0; width: 100%; height: auto; background-color: white; border: 1px solid rgba(0,0,0,0.1); box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <p align="center" style="color: black; font-size: 16px; margin-top: 11px;">2017 AUN Attendance System | Developed By <a href="#">MODU & AKIM</a></p>
                    </div>
                </div>
            </div>
        </footer>
        
        <script src="../bootstrap.min.css"></script>
        <script src="../jquery.js"></script>
    </body>
</html>