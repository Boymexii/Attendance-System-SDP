<?php
session_start();

if(isset($_SESSION['std_roll_no'])) {
    session_destroy();
    unset($_SESSION['std_roll_no']);
    unset($_SESSION['username']);
    header("Location: ../index.php");
} else {
    header("Location: ../index.php");
}
?>