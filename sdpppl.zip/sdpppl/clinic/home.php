<?php
session_start();
include_once '../config.php';
?> 

<html>
<head>
    <title>
        Clinic Home
    </title>
    <link href="../bootstrap.css" rel='stylesheet' type='text/css'>
        <link href="../style.css"  rel='stylesheet' type='text/css'> 
        <link href="../image/AUN.png" rel="icon">
        <script type="text/javascript" src="js/script.js" >
        </script>
        <script type="text/javascript" src="js/jq.js"></script>
</head>
<body>
    <div class="row">
  <div class="col-lg-6">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button">Go!</button>
      </span>
      <input type="text" class="form-control" placeholder="Search for...">
    </div><!-- /input-group -->
  </div><!-- /.col-lg-6 -->
</div><!-- /.row -->
</body>
</html>