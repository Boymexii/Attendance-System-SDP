function check_barcodee(){  
  
        //get the username
        var barcode = $('#barcode').val();  
  
        //use ajax to run the check  
        $.post("checkbarcode.php", { barcode: barcode },  
            function(result){  
                //if the result is 1  
                if(result == 1){  
                    //show that the username is available  
                    $("#check_barcode").click(function()
{ 
    $('#present').attr("checked", "checked");
});
                    return true;
                }else{  
                    //show that the username is NOT available  
                    return false;  
                }  
        });  
  
}  