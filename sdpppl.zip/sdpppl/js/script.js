function checkForm(aForm){
    if (aForm.barcode.value == ){
        alert('First name is empty');
        return false;
    }
    return true;
}
