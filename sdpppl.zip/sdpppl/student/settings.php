<?php
session_start();
include_once '../config.php';
?> 

<?php 
		if(isset($_POST['re_password']))
		{
        
            
		$new_pass=$_POST['new_pass'];
		$re_pass=$_POST['re_pass'];
        $old_pass = $_POST['old_pass'];
        $username = $_SESSION['username'];
        
            
        $result = mysqli_query($connect, "select * from student_table where username ='$username'");
        $row = mysqli_fetch_array($result);
        $password = $row['password'];
            
    
		if($old_pass==$password){
            if($new_pass==$re_pass){
            
			$update_pwd=mysqli_query($connect, "UPDATE student_table SET password = '$new_pass' WHERE username = '$username'");
            
			echo "<script>alert('Update Sucessfully'); window.location='settings.php'</script>";
            
		}
        }
		else{
			echo "<script>alert('Your new and Retype Password is not match'); window.location='settings.php'</script>";
		}
		
        }
	?>

<html>
<head>
    <title>Settings</title>
        <!-- Latest compiled and minified CSS -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="../image/AUN.png" rel="icon">
</head>
<body>
   <div class="container">
        <nav class="navbar navbar-default">
              <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="home.php" style="padding-top:0px; padding-left:1px;" >
                    <img alt="SAS" style="width:38%;" src="../logo.png">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username']; ?> <span class="caret"></span></a>
                      <ul class="dropdown-menu">
                        <li><a href="#">Settings</a></li>
                        <li><a href="logout.php">Logout</a></li>
                      </ul>
                    </li>
                  </ul>
                </div><!-- /.navbar-collapse -->
              </div><!-- /.container-fluid -->
            </nav>
       
        <table class="table table-bordered table-responsive" style="margin: 0 auto; margin-top: 130px; width: 500px;">
            <tbody>
                <form action="<?php $_SERVER['PHP_SELF'];?>" method="post">
                <tr>
                    <td colspan="2"><b>Change Password</b></td>
                </tr>
                <tr>
                    <td>Old Password</td>
                    <td><input class="form-control" placeholder="Enter New Password" type="text" name="old_pass" required></td>
                </tr>
                <tr>
                    <td>New Password</td>
                    <td><input class="form-control" placeholder="Enter New Password" type="text" name="new_pass" required></td>
                </tr>
                <tr>
                    <td>Confirm Password</td>
                    <td><input class="form-control" placeholder="Confirm Password" type="text" name="re_pass" required></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><input class="btn btn-primary" type="submit" name="re_password"></td>
                </tr>
                </form>
            </tbody>
        </table>
    </div> 
</body>
</html>